﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StoreAdminPortal.Controllers.Models
{
    public class Product
    {
        public string name { get; set; }
        public int price { get; set; }
    }
}